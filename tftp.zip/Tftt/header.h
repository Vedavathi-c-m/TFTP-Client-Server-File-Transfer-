/* Common file for both server and client
   This header file contains shared definitions,
   constants, structures and function declarations
   used by both client and server programs.
*/

#ifndef HEADER_H
#define HEADER_H

// Include standard integer types
#include <stdint.h>

// Include socket address structures
#include <arpa/inet.h>


// ------------------------------
// SERVER CONFIGURATION
// ------------------------------

// Server port number used for TFTP communication
#define PORT 6969

// Total TFTP packet size
// 512 bytes data + 4 bytes header
#define BUFFER_SIZE 516

// Timeout value (seconds) for retransmission
#define TIMEOUT_SEC 5


// ------------------------------
// TFTP OPERATION CODES
// ------------------------------

// Enumeration for different TFTP packet types
typedef enum {

    RRQ = 1,   // Read Request → client requests file from server

    WRQ = 2,   // Write Request → client uploads file to server

    DATA = 3,  // Data Packet → actual file data transfer

    ACK = 4,   // Acknowledgment → confirmation of received block

    ERROR = 5  // Error Packet → error message if problem occurs

} tftp_opcode;


// ------------------------------
// TFTP PACKET STRUCTURE
// ------------------------------

// This structure defines the format of TFTP packets
// All packets start with an opcode

typedef struct {

    // Operation code indicating packet type
    uint16_t opcode;

    // Union allows different packet formats
    // depending on opcode

    union {

        // ------------------------------
        // RRQ / WRQ packet format
        // ------------------------------
        struct {

            // Name of file requested or sent
            char filename[256];

            // Transfer mode (usually "octet")
            char mode[8];

        } request;


        // ------------------------------
        // DATA packet format
        // ------------------------------
        struct {

            // Block number of the data packet
            uint16_t block_number;

            // Actual data being transferred
            char data[512];

        } data_packet;


        // ------------------------------
        // ACK packet format
        // ------------------------------
        struct {

            // Block number being acknowledged
            uint16_t block_number;

        } ack_packet;


        // ------------------------------
        // ERROR packet format
        // ------------------------------
        struct {

            // Error code indicating error type
            uint16_t error_code;

            // Error message description
            char error_msg[512];

        } error_packet;

    } body;

} tftp_packet;


// ------------------------------
// FUNCTION DECLARATIONS
// ------------------------------

// Function used by server to send file to client
// Parameters:
// sockfd → socket descriptor
// client_addr → client IP address
// client_len → length of address
// filename → file to send

void send_file(int sockfd,
               struct sockaddr_in client_addr,
               socklen_t client_len,
               char *filename);


// Function used by server to receive file from client
// Parameters:
// sockfd → socket descriptor
// client_addr → client IP address
// client_len → length of address
// filename → file to receive

void receive_file(int sockfd,
                  struct sockaddr_in client_addr,
                  socklen_t client_len,
                  char *filename);


#endif