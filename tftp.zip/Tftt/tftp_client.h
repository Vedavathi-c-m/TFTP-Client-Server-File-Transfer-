#ifndef TFTP_CLIENT_H
#define TFTP_CLIENT_H

// Include Internet address structures for socket programming
#include <arpa/inet.h>


// --------------------------------------------------
// CLIENT STRUCTURE
// --------------------------------------------------

// This structure stores all information required
// for the client to communicate with the TFTP server

typedef struct {

    // Socket file descriptor used for communication
    int sockfd;

    // Structure that stores server IP address and port
    struct sockaddr_in server_addr;

    // Length of server address structure
    socklen_t server_len;

    // Character array to store server IP address as string
    char server_ip[INET_ADDRSTRLEN];

} tftp_client_t;


// --------------------------------------------------
// FUNCTION DECLARATIONS
// --------------------------------------------------


// Function: connect_to_server()
// Purpose:
// Creates UDP socket and initializes server address

// Parameters:
// client → pointer to client structure
// ip → server IP address
// port → server port number

void connect_to_server(tftp_client_t *client, char *ip, int port);



// Function: put_file()
// Purpose:
// Upload file from client to server using TFTP WRQ request

// Parameters:
// client → client structure containing socket and address
// filename → name of file to upload

void put_file(tftp_client_t *client, char *filename);



// Function: get_file()
// Purpose:
// Download file from server to client using TFTP RRQ request

// Parameters:
// client → client structure
// filename → file name requested from server

void get_file(tftp_client_t *client, char *filename);



// --------------------------------------------------
// REQUEST HANDLING FUNCTIONS
// --------------------------------------------------


// Function: send_request()
// Purpose:
// Sends a TFTP request packet to server

// Parameters:
// sockfd → client socket descriptor
// server_addr → server address structure
// filename → name of file requested
// opcode → type of request (RRQ or WRQ)

void send_request(int sockfd,
                  struct sockaddr_in server_addr,
                  char *filename,
                  int opcode);



// Function: receive_request()
// Purpose:
// Receives response packets from server

// Parameters:
// sockfd → client socket descriptor
// server_addr → server address
// filename → requested filename
// opcode → request type

void receive_request(int sockfd,
                     struct sockaddr_in server_addr,
                     char *filename,
                     int opcode);


#endif