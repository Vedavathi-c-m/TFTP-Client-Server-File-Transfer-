// Include common definitions used by both client and server
#include "header.h"

// Include client structure and client functions
#include "tftp_client.h"

// Standard input output library
#include <stdio.h>

// Standard library for exit()
#include <stdlib.h>

// String manipulation functions
#include <string.h>

// Unix system calls like read(), write()
#include <unistd.h>

// Internet address structures
#include <arpa/inet.h>


// -----------------------------
// CLIENT MAIN PROGRAM
// -----------------------------
int main()
{

    // command buffer (currently unused but can store user commands)
    char command[256];

    // Create client structure to store socket and server information
    tftp_client_t client;

    // variable to store user menu choice
    int choice;

    // filename buffer for PUT and GET operations
    char filename[100];

    // buffer to store server IP address
    char ip[INET_ADDRSTRLEN];



    // ---------------------------------------
    // Infinite loop to display menu repeatedly
    // ---------------------------------------
    while(1)
    {

        // Display client menu options
        printf("\n==============================\n");
        printf("        TFTP CLIENT MENU      \n");
        printf("==============================\n");

        printf("1. Connect to Server\n");   // establish connection
        printf("2. Put (Upload File)\n");   // send file to server
        printf("3. Get (Download File)\n"); // receive file from server
        printf("4. Mode\n");                // transfer mode option
        printf("5. Exit\n");                // exit program

        printf("Enter the choice: ");

        // Read user choice
        scanf("%d",&choice);


        // ---------------------------------------
        // Perform action based on user selection
        // ---------------------------------------
        switch(choice)
        {

            // ---------------------------------------
            // CASE 1 : CONNECT TO SERVER
            // ---------------------------------------
            case 1:

                // Ask user to enter server IP address
                printf("Enter server IP address: ");

                scanf("%s",ip);

                // Call function to create socket and connect
                connect_to_server(&client,ip,PORT);

                break;



            // ---------------------------------------
            // CASE 2 : PUT FILE (UPLOAD)
            // ---------------------------------------
            case 2:

                // Ask user for file name to upload
                printf("Enter the filename to send: ");

                scanf("%s",filename);

                // Call put_file function to send file
                put_file(&client,filename);

                break;



            // ---------------------------------------
            // CASE 3 : GET FILE (DOWNLOAD)
            // ---------------------------------------
            case 3:

                // Ask user for filename to download
                printf("Enter the filename to receive: ");

                scanf("%s",filename);

                // Call get_file function to receive file
                get_file(&client,filename);

                break;



            // ---------------------------------------
            // CASE 4 : MODE OPTION
            // ---------------------------------------
            case 4:

                // Mode option currently not implemented
                printf("Mode option not implemented yet\n");

                break;



            // ---------------------------------------
            // CASE 5 : EXIT PROGRAM
            // ---------------------------------------
            case 5:

                // terminate the client program
                printf("Exiting TFTP Client...\n");

                exit(0);



            // ---------------------------------------
            // INVALID INPUT
            // ---------------------------------------
            default:

                printf("Invalid choice. Please try again.\n");

        }

    }


    // program termination
    return 0;

}