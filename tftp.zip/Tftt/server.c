// Include common header file
// Contains packet structure, constants and function prototypes
#include "header.h"

// Standard input-output functions like printf()
#include <stdio.h>

// String manipulation functions like memset() and strcpy()
#include <string.h>

// UNIX system calls like read(), write(), close()
#include <unistd.h>

// Standard library functions like exit()
#include <stdlib.h>

// File control operations like open()
#include <fcntl.h>


// -----------------------------------------------------------
// SERVER MAIN PROGRAM
// -----------------------------------------------------------
int main()
{

    // Socket file descriptor
    int sockfd;

    // Server and client address structures
    struct sockaddr_in server_addr, client_addr;

    // Length of client address
    socklen_t client_len;

    // Packet structures used for TFTP communication
    tftp_packet packet, ack;


    // -----------------------------------------------------------
    // STEP 1: CREATE UDP SOCKET
    // AF_INET   → IPv4 protocol
    // SOCK_DGRAM → UDP socket
    // -----------------------------------------------------------
    sockfd = socket(AF_INET,SOCK_DGRAM,0);


    // -----------------------------------------------------------
    // STEP 2: INITIALIZE SERVER ADDRESS STRUCTURE
    // -----------------------------------------------------------
    memset(&server_addr,0,sizeof(server_addr));

    // Use IPv4 protocol
    server_addr.sin_family = AF_INET;

    // Convert port number to network byte order
    server_addr.sin_port = htons(PORT);

    // Accept connections from any IP address
    server_addr.sin_addr.s_addr = INADDR_ANY;


    // -----------------------------------------------------------
    // STEP 3: BIND SOCKET TO PORT
    // This allows server to listen on the specified port
    // -----------------------------------------------------------
    bind(sockfd,(struct sockaddr *)&server_addr,sizeof(server_addr));


    // Display message that server started
    printf("TFTP Server listening on port %d\n",PORT);


    // -----------------------------------------------------------
    // STEP 4: SERVER LOOP
    // Server continuously waits for client requests
    // -----------------------------------------------------------
    while(1)
    {

        // Store size of client address
        client_len = sizeof(client_addr);


        // -----------------------------------------------------------
        // STEP 5: RECEIVE REQUEST FROM CLIENT
        // recvfrom() receives packet and stores client address
        // -----------------------------------------------------------
        recvfrom(sockfd,
                 &packet,
                 sizeof(packet),
                 0,
                 (struct sockaddr *)&client_addr,
                 &client_len);


        // Convert opcode from network byte order to host byte order
        uint16_t opcode = ntohs(packet.opcode);


        // Variable to store requested filename
        char filename[256];

        // Copy filename from received packet
        strcpy(filename,packet.body.request.filename);


        // -----------------------------------------------------------
        // STEP 6: HANDLE RRQ (READ REQUEST)
        // Client wants to download file from server
        // -----------------------------------------------------------
        if(opcode == RRQ)
        {

            printf("RRQ received for file: %s\n",filename);

            // Call function to send file to client
            send_file(sockfd,client_addr,client_len,filename);

        }


        // -----------------------------------------------------------
        // STEP 7: HANDLE WRQ (WRITE REQUEST)
        // Client wants to upload file to server
        // -----------------------------------------------------------
        else if(opcode == WRQ)
        {

            printf("WRQ received for file: %s\n",filename);

            // Call function to receive file from client
            receive_file(sockfd,client_addr,client_len,filename);

        }

    }


    // -----------------------------------------------------------
    // STEP 8: CLOSE SOCKET (never reached in this infinite loop)
    // -----------------------------------------------------------
    close(sockfd);

    return 0;

}