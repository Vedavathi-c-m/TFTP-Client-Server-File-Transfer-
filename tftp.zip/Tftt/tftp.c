// Include common header file containing packet structure and constants
#include "header.h"

// Standard input-output functions like printf()
#include <stdio.h>

// String manipulation functions like memset()
#include <string.h>

// UNIX system calls
#include <unistd.h>


// -------------------------------------------------------
// FUNCTION: send_file()
// PURPOSE : Send file from server to client (RRQ request)
// -------------------------------------------------------
void send_file(int sockfd,
               struct sockaddr_in client_addr,
               socklen_t client_len,
               char *filename)
{

    // Declare packet structures for DATA and ACK
    tftp_packet packet, ack;

    // Open file in binary read mode
    FILE *fp = fopen(filename,"rb");

    // If file cannot be opened
    if(!fp)
    {
        perror("File open failed");
        return;
    }

    // Block number starts from 1
    uint16_t block = 1;

    // Variable to store number of bytes read
    int n;

    // ---------------------------------------------------
    // Loop until entire file is sent
    // ---------------------------------------------------
    while(1)
    {

        // Clear packet structure
        memset(&packet,0,sizeof(packet));

        // Read 512 bytes from file
        n = fread(packet.body.data_packet.data,1,512,fp);

        // Set packet opcode to DATA
        packet.opcode = htons(DATA);

        // Set block number in network byte order
        packet.body.data_packet.block_number = htons(block);

        // ------------------------------------------------
        // Send DATA packet to client
        // Packet size = header (4 bytes) + data
        // ------------------------------------------------
        sendto(sockfd,
               &packet,
               4+n,
               0,
               (struct sockaddr *)&client_addr,
               client_len);

        // ------------------------------------------------
        // Wait for ACK packet from client
        // ------------------------------------------------
        recvfrom(sockfd,
                 &ack,
                 sizeof(ack),
                 0,
                 (struct sockaddr *)&client_addr,
                 &client_len);

        // ------------------------------------------------
        // Verify ACK block number
        // ------------------------------------------------
        if(ntohs(ack.body.ack_packet.block_number) != block)
        {
            printf("ACK mismatch\n");
            break;
        }

        // ------------------------------------------------
        // If last packet (less than 512 bytes)
        // transfer is complete
        // ------------------------------------------------
        if(n < 512)
            break;

        // Move to next block
        block++;

    }

    // Close file after sending
    fclose(fp);

    // Display completion message
    printf("File sent successfully\n");

}



// -------------------------------------------------------
// FUNCTION: receive_file()
// PURPOSE : Receive file from client (WRQ request)
// -------------------------------------------------------
void receive_file(int sockfd,
                  struct sockaddr_in client_addr,
                  socklen_t client_len,
                  char *filename)
{

    // Packet structures for receiving data and sending ACK
    tftp_packet packet, ack;

    // Open file in binary write mode
    FILE *fp = fopen(filename,"wb");

    // If file cannot be created
    if(!fp)
    {
        perror("File open failed");
        return;
    }

    // Variable to store number of bytes received
    int n;

    // Expected block number
    uint16_t expected_block = 1;

    // ---------------------------------------------------
    // Loop to receive data blocks from client
    // ---------------------------------------------------
    while(1)
    {

        // Clear packet structure
        memset(&packet,0,sizeof(packet));

        // ------------------------------------------------
        // Receive DATA packet from client
        // ------------------------------------------------
        n = recvfrom(sockfd,
                     &packet,
                     sizeof(packet),
                     0,
                     (struct sockaddr *)&client_addr,
                     &client_len);

        // Extract block number from packet
        uint16_t block = ntohs(packet.body.data_packet.block_number);

        // ------------------------------------------------
        // Check if received block is expected
        // ------------------------------------------------
        if(block == expected_block)
        {

            // Write received data to file
            fwrite(packet.body.data_packet.data,
                   1,
                   n-4,
                   fp);

            // Increment expected block number
            expected_block++;

        }

        // ------------------------------------------------
        // Send ACK packet to client
        // ------------------------------------------------
        ack.opcode = htons(ACK);

        // Acknowledge received block
        ack.body.ack_packet.block_number = htons(block);

        sendto(sockfd,
               &ack,
               4,
               0,
               (struct sockaddr *)&client_addr,
               client_len);

        // ------------------------------------------------
        // Last packet detection
        // If received packet < BUFFER_SIZE
        // file transfer completed
        // ------------------------------------------------
        if(n < BUFFER_SIZE)
            break;

    }

    // Close file after receiving
    fclose(fp);

    // Print completion message
    printf("File received successfully\n");

}