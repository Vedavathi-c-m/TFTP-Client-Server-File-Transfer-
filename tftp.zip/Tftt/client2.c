// Include common definitions (PORT, packet structure etc.)
#include "header.h"

// Include client structure and client function declarations
#include "tftp_client.h"

// Standard input-output library
#include <stdio.h>

// Standard library for exit(), memory allocation etc.
#include <stdlib.h>

// String manipulation functions
#include <string.h>

// UNIX system calls like read(), write(), close()
#include <unistd.h>

// Internet socket structures and functions
#include <arpa/inet.h>

// File control operations (open, O_RDONLY etc.)
#include <fcntl.h>


// ----------------------------------------------------
// FUNCTION: connect_to_server()
// PURPOSE : Initialize UDP socket and configure server
// ----------------------------------------------------
void connect_to_server(tftp_client_t *client, char *ip, int port)
{

    int dot_count = 0;

    // --------------------------------------------
    // Validate IP address by counting dots
    // A valid IPv4 address normally has 3 dots
    // Example: 192.168.1.1
    // --------------------------------------------
    for(int i=0; ip[i] != '\0'; i++)
    {

        if(ip[i] == '.')
            dot_count++;

    }

    if(dot_count >= 3)
    {

        // --------------------------------------------
        // Create UDP socket
        // AF_INET   → IPv4 protocol
        // SOCK_DGRAM → UDP socket
        // --------------------------------------------
        client->sockfd = socket(AF_INET,SOCK_DGRAM,0);

        if(client->sockfd < 0)
        {
            perror("socket");
            return;
        }

        // --------------------------------------------
        // Initialize server address structure
        // --------------------------------------------
        memset(&client->server_addr,0,sizeof(client->server_addr));

        // Specify IPv4 protocol
        client->server_addr.sin_family = AF_INET;

        // Convert port number to network byte order
        client->server_addr.sin_port = htons(port);

        // Convert IP address string to binary format
        client->server_addr.sin_addr.s_addr = inet_addr(ip);

        // Store server address length
        client->server_len = sizeof(client->server_addr);

    }
    else
    {

        printf("IP address not valid\n");

        return;

    }

    // Print connection message
    printf("Connected to %s:%d\n",ip,port);

}



// ----------------------------------------------------
// FUNCTION: put_file()
// PURPOSE : Upload file from client to server
// ----------------------------------------------------
void put_file(tftp_client_t *client, char *filename)
{

    // Buffer to store file data (512 bytes block)
    char buffer[512];

    // Request buffer
    char request[200];

    int bytes;

    // --------------------------------------------
    // Open file for reading
    // --------------------------------------------
    int fd = open(filename,O_RDONLY);

    if(fd == -1)
    {

        printf("File does not exist\n");

        return;

    }

    // --------------------------------------------
    // Create WRQ (Write Request)
    // This tells server client wants to upload file
    // --------------------------------------------
    sprintf(request,"WRQ %s",filename);

    // Send request to server
    sendto(client->sockfd,
           request,
           strlen(request)+1,
           0,
           (struct sockaddr *)&client->server_addr,
           client->server_len);

    printf("PUT request sent\n");

    // --------------------------------------------
    // Wait for server acknowledgment
    // --------------------------------------------
    char ack[10];

    recvfrom(client->sockfd,ack,sizeof(ack),0,NULL,NULL);

    // Check if server accepted request
    if(strcmp(ack,"OK") != 0)
    {

        printf("Server rejected request\n");

        close(fd);

        return;

    }

    printf("Sending file...\n");

    int block = 1;

    // --------------------------------------------
    // Send file in blocks of 512 bytes
    // --------------------------------------------
    while((bytes = read(fd,buffer,512)) > 0)
    {

        // Send data block
        sendto(client->sockfd,
               buffer,
               bytes,
               0,
               (struct sockaddr *)&client->server_addr,
               client->server_len);

        int ack_block;

        // Wait for ACK from server
        recvfrom(client->sockfd,
                 &ack_block,
                 sizeof(ack_block),
                 0,
                 NULL,
                 NULL);

        // Verify correct ACK block number
        if(ack_block != block)
        {

            printf("ACK mismatch, resending\n");

            // Move file pointer back to resend block
            lseek(fd,-bytes,SEEK_CUR);

            continue;

        }

        // Move to next block
        block++;

    }

    printf("File transfer completed\n");

    close(fd);

}



// ----------------------------------------------------
// FUNCTION: get_file()
// PURPOSE : Download file from server to client
// ----------------------------------------------------
void get_file(tftp_client_t *client, char *filename)
{

    char buffer[512];

    char request[200];

    int bytes;

    // --------------------------------------------
    // Create RRQ (Read Request)
    // This tells server client wants to download file
    // --------------------------------------------
    sprintf(request,"RRQ %s",filename);

    // Send request to server
    sendto(client->sockfd,
           request,
           strlen(request)+1,
           0,
           (struct sockaddr *)&client->server_addr,
           client->server_len);

    printf("GET request sent\n");

    // --------------------------------------------
    // Create local file to store received data
    // --------------------------------------------
    int fd = open(filename,O_WRONLY | O_CREAT | O_TRUNC ,0666);

    if(fd == -1)
    {

        printf("Error creating file\n");

        return;

    }

    int block = 1;

    printf("Receiving file...\n");

    // --------------------------------------------
    // Receive data blocks from server
    // --------------------------------------------
    while(1)
    {

        bytes = recvfrom(client->sockfd,
                         buffer,
                         512,
                         0,
                         NULL,
                         NULL);

        // If no data received, stop
        if(bytes <= 0)
            break;

        // Write received data to file
        write(fd,buffer,bytes);

        // Send ACK to server
        sendto(client->sockfd,
               &block,
               sizeof(block),
               0,
               (struct sockaddr *)&client->server_addr,
               client->server_len);

        // Last block detection
        if(bytes < 512)
            break;

        block++;

    }

    printf("File received successfully\n");

    close(fd);

}